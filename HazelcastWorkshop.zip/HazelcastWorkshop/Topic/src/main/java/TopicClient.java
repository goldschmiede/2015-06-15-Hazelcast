import com.hazelcast.client.HazelcastClient;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;


public class TopicClient 
{

	public static void main(String[] args) 
	{
		HazelcastInstance hz = HazelcastClient.newHazelcastClient();
		ITopic<String> topic = hz.getTopic("time");
		
		topic.addMessageListener(s->System.out.println("Beim nächsten Ton ist es: " + s.getMessageObject()));
	}
}
