import com.hazelcast.client.HazelcastClient;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;


public class ChatClient 
{

	public static void main(String[] args) 
	{
		String message = System.getenv("USERNAME") + " grüßt die Welt";
		if(args.length>0)
			message = args[0];
		
		HazelcastInstance hz = HazelcastClient.newHazelcastClient();
		ITopic<String> topic = hz.getTopic("chat");
		topic.publish(message);
		
		System.exit(0);
	}
}
