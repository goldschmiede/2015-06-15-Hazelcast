import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Queue;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IQueue;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.ItemEvent;
import com.hazelcast.core.ItemListener;

public class QueueServer {
    public static void main(String[] args) throws Exception 
    {
        HazelcastInstance hz = Hazelcast.newHazelcastInstance();
        System.out.println("Finished Init");
        
        Queue<String> q = hz.getQueue("testq");

        for(int i=0; i<10; i++)
        {
        	q.add("Item " + i);
        }
        
        // set listener
        ((IQueue<String>)q).addItemListener(new MyItemListener(), true);
            
    }
    
    public static class MyItemListener implements ItemListener<String>
    {
		@Override
		public void itemRemoved(ItemEvent<String> arg0) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void itemAdded(ItemEvent<String> s) {
			System.out.println("Item added <" + s + ">");
		}
    }
}
