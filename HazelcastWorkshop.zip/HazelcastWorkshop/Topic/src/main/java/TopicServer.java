import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;

public class TopicServer {
    public static void main(String[] args) throws Exception 
    {
        HazelcastInstance hz = Hazelcast.newHazelcastInstance();
        System.out.println("Finished Init");
        
        ITopic<String> topicChat = hz.getTopic("chat");
        topicChat.addMessageListener(s->System.out.println("Chat Message: <" + s.getMessageObject() + ">"));
        
        ITopic<String> topicTime = hz.getTopic("time");
        
        for(;;)
        {
        	Thread.sleep(10000);
        	DateTimeFormatter fmt = DateTimeFormatter.ISO_DATE_TIME;
        	String currentTime = fmt.format(LocalDateTime.now());
        	System.out.println("Publishing '" + currentTime + "'");
        	topicTime.publish(currentTime);
        }
        
    }
}
